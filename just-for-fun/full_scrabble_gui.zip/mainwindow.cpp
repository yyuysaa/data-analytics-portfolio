#include "mainwindow.h"
#include <QVBoxLayout>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), central(new QWidget(this)), boardLayout(new QGridLayout) {
    setWindowTitle("Scrabble GUI Game");

    setupBoard();

    central->setLayout(boardLayout);
    setCentralWidget(central);
}

MainWindow::~MainWindow() {}

void MainWindow::setupBoard() {
    for (int row = 0; row < 15; ++row) {
        QVector<QPushButton*> rowButtons;
        for (int col = 0; col < 15; ++col) {
            QPushButton *btn = new QPushButton("");
            btn->setFixedSize(40, 40);
            connect(btn, &QPushButton::clicked, this, &MainWindow::handleTileClick);
            boardLayout->addWidget(btn, row, col);
            rowButtons.append(btn);
        }
        boardButtons.append(rowButtons);
    }
}

void MainWindow::handleTileClick() {
    QPushButton *btn = qobject_cast<QPushButton*>(sender());
    if (btn->text().isEmpty()) {
        btn->setText("A");  // Placeholder for tile selection
    } else {
        btn->setText("");
    }
}