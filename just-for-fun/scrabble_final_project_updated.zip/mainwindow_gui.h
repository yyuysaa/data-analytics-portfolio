#ifndef MAINWINDOW_GUI_H
#define MAINWINDOW_GUI_H

#include <QMainWindow>
#include <QGridLayout>
#include <QPushButton>
#include <QLabel>
#include <vector>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindowGUI; }
QT_END_NAMESPACE

class MainWindowGUI : public QMainWindow {
    Q_OBJECT

public:
    MainWindowGUI(QWidget *parent = nullptr);
    ~MainWindowGUI();

private slots:
    void handleButtonClick();

private:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    std::vector<std::vector<QPushButton*>> boardButtons;
    void setupBoard();
};

#endif // MAINWINDOW_GUI_H