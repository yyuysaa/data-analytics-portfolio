#include "mainwindow_gui.h"

MainWindowGUI::MainWindowGUI(QWidget *parent)
    : QMainWindow(parent), centralWidget(new QWidget(this)), gridLayout(new QGridLayout) {
    setWindowTitle("Scrabble GUI Board");
    setupBoard();
    centralWidget->setLayout(gridLayout);
    setCentralWidget(centralWidget);
}

MainWindowGUI::~MainWindowGUI() {}

void MainWindowGUI::setupBoard() {
    for (int i = 0; i < 15; ++i) {
        std::vector<QPushButton*> row;
        for (int j = 0; j < 15; ++j) {
            QPushButton* btn = new QPushButton("");
            btn->setFixedSize(40, 40);
            connect(btn, &QPushButton::clicked, this, &MainWindowGUI::handleButtonClick);
            gridLayout->addWidget(btn, i, j);
            row.push_back(btn);
        }
        boardButtons.push_back(row);
    }
}

void MainWindowGUI::handleButtonClick() {
    QPushButton* btn = qobject_cast<QPushButton*>(sender());
    if (btn->text().isEmpty())
        btn->setText("A");
    else
        btn->setText("");
}