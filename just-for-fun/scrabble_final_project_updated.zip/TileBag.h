#ifndef TILEBAG_H
#define TILEBAG_H

#include <vector>
#include <random>
#include <algorithm>
#include "Tile.h"

class TileBag {
public:
    TileBag();
    Tile drawTile();
    void returnTile(const Tile& tile);
    bool isEmpty() const;

private:
    std::vector<Tile> tiles;
    std::mt19937 rng;
};

#endif