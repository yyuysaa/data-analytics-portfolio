#ifndef BOARD_H
#define BOARD_H

#include <vector>
#include <string>
#include "Tile.h"

class Board {
public:
    Board();
    void display() const;
    bool placeWord(const std::string& word, int row, int col, bool horizontal);
    bool isValidPosition(int row, int col, const std::string& word, bool horizontal) const;

private:
    std::vector<std::vector<Tile>> grid;
};

#endif