#ifndef TILE_H
#define TILE_H

#include <string>

class Tile {
public:
    Tile(char letter = ' ', int value = 0, bool isBlank = false);
    char getLetter() const;
    int getValue() const;
    bool isBlankTile() const;
    void setLetter(char l);

private:
    char letter;
    int value;
    bool blank;
};

#endif