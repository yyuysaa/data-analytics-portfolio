#ifndef PLAYER_H
#define PLAYER_H

#include <string>
#include <vector>
#include "Tile.h"

class Player {
public:
    Player(const std::string& name);
    std::string getName() const;
    int getScore() const;
    void addScore(int points);
    std::vector<Tile>& getTiles();
    void drawTiles(std::vector<Tile>& bag, int count);
    void returnTiles(std::vector<Tile>& bag);

private:
    std::string name;
    int score;
    std::vector<Tile> tiles;
};

#endif