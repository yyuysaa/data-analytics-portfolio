#ifndef GAME_H
#define GAME_H

#include <vector>
#include <string>
#include <unordered_set>
#include "Player.h"
#include "Board.h"

class Game {
public:
    Game();
    void start();

private:
    std::vector<Player> players;
    std::vector<Tile> tileBag;
    Board board;
    std::unordered_set<std::string> dictionary;

    void initializePlayers();
    void initializeTiles();
    void loadDictionary(const std::string& filename);
    Tile drawRandomTile();
};

#endif